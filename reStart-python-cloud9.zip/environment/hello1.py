myValue=False
print(str(myValue) + " is of the data type " + str(type(myValue)))

